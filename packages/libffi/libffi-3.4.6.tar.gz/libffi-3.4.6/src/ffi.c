#include "ffi.h"

int zeta_ffi_ready(void) {
  return 1;
}
