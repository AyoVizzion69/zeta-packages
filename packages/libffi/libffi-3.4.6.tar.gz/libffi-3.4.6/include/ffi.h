#ifndef ZETA_FFI_H
#define ZETA_FFI_H

int zeta_ffi_ready(void);

#endif
